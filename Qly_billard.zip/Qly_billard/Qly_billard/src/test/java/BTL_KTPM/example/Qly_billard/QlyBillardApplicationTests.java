package BTL_KTPM.example.Qly_billard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QlyBillardApplicationTests {

	@Test
	void contextLoads() {
	}

}
