package BTL_KTPM.example.Qly_billard.Controller;

import BTL_KTPM.example.Qly_billard.DTO.BillRequest;
import BTL_KTPM.example.Qly_billard.Entity.Bills;
import BTL_KTPM.example.Qly_billard.Service.BillsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/bills")
public class BillsController {

    @Autowired
    private BillsService billsService;

    @GetMapping("/findAll")
    public Iterable<Bills> getAllBills() {
        return billsService.findAll();
    }

    @GetMapping("findId/{id}")
    public ResponseEntity<Bills> getBillById(@PathVariable Integer id) {
        Bills bills = billsService.findById(id);
        return ResponseEntity.ok(bills);
    }

    @PostMapping("/create")
    public Bills createBill(@RequestBody BillRequest bills) {
        return billsService.save(bills);
    }

    @PutMapping("update/{id}")
    public ResponseEntity<Bills> updateBill(@PathVariable Integer id, @RequestBody Bills billsDetails) {
        Bills updatedBills = billsService.update(id, billsDetails);
        return ResponseEntity.ok(updatedBills);
    }

    @DeleteMapping("delete/{id}")
    public ResponseEntity<Void> deleteBill(@PathVariable Integer id) {
        billsService.delete(id);
        return ResponseEntity.noContent().build();
    }
    @GetMapping("/findDate/{date}")
    public Iterable<Bills> FindByDate(@PathVariable LocalDate date){
        return billsService.findByDate(date);
    }
    @GetMapping("/moneyToday")
    public Integer MoneyToday(){
        return billsService.allBillToday();
    }
    @GetMapping("/moneyYesterday")
    public Integer MoneyYesterday(){
        return billsService.allBillYesterday();
    }

    @GetMapping("/moneyByHour")
    public int[] MoneyByHour(){
        return billsService.calculateHourlyRevenue();
    }
}

