package BTL_KTPM.example.Qly_billard.Repository;

import BTL_KTPM.example.Qly_billard.Entity.Users;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsersRepository extends JpaRepository<Users,Integer> {
}
