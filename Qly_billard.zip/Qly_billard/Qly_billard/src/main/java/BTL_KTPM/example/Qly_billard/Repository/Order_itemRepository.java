package BTL_KTPM.example.Qly_billard.Repository;

import BTL_KTPM.example.Qly_billard.Entity.Items;
import BTL_KTPM.example.Qly_billard.Entity.Order_item;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Order_itemRepository extends JpaRepository<Order_item,Integer> {
}
