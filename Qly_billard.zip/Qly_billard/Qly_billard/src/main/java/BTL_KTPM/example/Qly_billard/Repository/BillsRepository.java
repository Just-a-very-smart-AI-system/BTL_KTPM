package BTL_KTPM.example.Qly_billard.Repository;

import BTL_KTPM.example.Qly_billard.Entity.Bills;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

public interface BillsRepository extends JpaRepository<Bills, Integer> {
    @Query(value = "Select * from bills where date_pay = :date", nativeQuery = true)
    Iterable<Bills> findByDatePay(@Param("date") LocalDate date);
    Iterable<Bills> findByDatePayAndTimeBetween(LocalDate datePay, LocalTime startTime, LocalTime endTime);

}
