package BTL_KTPM.example.Qly_billard.Controller;

import BTL_KTPM.example.Qly_billard.Entity.Users;
import BTL_KTPM.example.Qly_billard.Service.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
public class UsersController {

    @Autowired
    private UsersService usersService;

    @GetMapping("/findALl")
    public Iterable<Users> getAllUsers() {
        return usersService.findAll();
    }

    @GetMapping("findId/{id}")
    public ResponseEntity<Users> getUserById(@PathVariable Integer id) {
        Users user = usersService.findById(id);
        return ResponseEntity.ok(user);
    }

    @PostMapping("/create")
    public Users createUser(@RequestBody Users user) {
        return usersService.save(user);
    }

    @PutMapping("update/{id}")
    public ResponseEntity<Users> updateUser(@PathVariable Integer id, @RequestBody Users userDetails) {
        Users updatedUser = usersService.update(id, userDetails);
        return ResponseEntity.ok(updatedUser);
    }

    @DeleteMapping("delete/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Integer id) {
        usersService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
