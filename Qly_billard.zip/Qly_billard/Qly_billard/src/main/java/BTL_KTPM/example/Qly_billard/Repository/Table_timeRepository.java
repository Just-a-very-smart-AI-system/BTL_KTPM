package BTL_KTPM.example.Qly_billard.Repository;

import BTL_KTPM.example.Qly_billard.Entity.Table_time;
import BTL_KTPM.example.Qly_billard.Entity.Tables;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface Table_timeRepository extends JpaRepository<Table_time, Integer> {
    @Query(value = "SELECT * FROM tables_time WHERE tables_time.table_id = :tableId", nativeQuery = true)
    Iterable<Table_time> findAllByTables(@Param("tableId") Integer tableId);

}
