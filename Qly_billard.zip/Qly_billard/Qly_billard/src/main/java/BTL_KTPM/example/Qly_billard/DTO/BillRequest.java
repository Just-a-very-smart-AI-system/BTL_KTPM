package BTL_KTPM.example.Qly_billard.DTO;

import BTL_KTPM.example.Qly_billard.Entity.Users;
import jakarta.persistence.Column;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BillRequest {
    private Integer user;

    private Integer totalMoney;

    private LocalDate datePay;

    private LocalTime time;
}
