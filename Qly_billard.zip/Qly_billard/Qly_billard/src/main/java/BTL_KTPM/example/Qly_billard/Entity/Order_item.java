package BTL_KTPM.example.Qly_billard.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "order_item")
@AllArgsConstructor
@NoArgsConstructor
public class Order_item {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "table_id", foreignKey = @ForeignKey(name = "FK_order_item_tables"), nullable = true)
    private Tables table;

    @ManyToOne
    @JoinColumn(name = "item_id", foreignKey = @ForeignKey(name = "FK_order_item_items"), nullable = true)
    private Items item;

    @Column(name = "quantity", nullable = true)
    private Integer quantity;

    @Column(name = "total_price", nullable = true)
    private Integer totalPrice;
}
