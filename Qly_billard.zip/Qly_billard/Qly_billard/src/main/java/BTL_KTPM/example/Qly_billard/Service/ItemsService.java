package BTL_KTPM.example.Qly_billard.Service;

import BTL_KTPM.example.Qly_billard.Entity.Items;
import BTL_KTPM.example.Qly_billard.Repository.ItemsRepository; // Đảm bảo bạn đã tạo ItemsRepository
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

@Service
public class ItemsService {

    @Autowired
    private ItemsRepository itemsRepository;

    // Tìm tất cả các item
    public Iterable<Items> findAll() {
        return itemsRepository.findAll();
    }

    // Tìm item theo ID
    public Items findById(Integer id) {
        return itemsRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Item not found for this id: " + id));
    }

    // Lưu item mới
    public Items save(Items item) {
        return itemsRepository.save(item);
    }

    // Cập nhật item theo ID
    public Items update(Integer id, Items itemDetails) {
        Items item = findById(id);
        item.setName(itemDetails.getName());
        item.setPrice(itemDetails.getPrice());
        return itemsRepository.save(item);
    }

    // Xóa item theo ID
    public void delete(Integer id) {
        Items item = findById(id);
        itemsRepository.delete(item);
    }
    public Iterable<Items> findFood(){
        List<Items> items = new ArrayList<>();
        for(int i = 1; i <= 5; i++){
            items.add(findById(i));
        }

        return items;
    }
    public Iterable<Items> findDrink(){
        List<Items> items = new ArrayList<>();
        for(int i = 6; i <= 10; i++){
            items.add(findById(i));
        }

        return items;
    }
}
