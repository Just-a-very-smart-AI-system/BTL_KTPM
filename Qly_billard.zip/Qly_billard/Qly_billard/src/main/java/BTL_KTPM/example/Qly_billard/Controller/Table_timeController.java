package BTL_KTPM.example.Qly_billard.Controller;

import BTL_KTPM.example.Qly_billard.DTO.TimeRequest;
import BTL_KTPM.example.Qly_billard.Entity.Table_time;
import BTL_KTPM.example.Qly_billard.Service.Table_timeService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/time")
public class Table_timeController {
    @Autowired
    private Table_timeService tableTimeService;

    @GetMapping("/findAll")
    public Iterable<Table_time> FindAll(){
        return tableTimeService.FindAll();
    }
    @GetMapping("/findId/{id}")
    public Table_time FindById(@PathVariable Integer id){
        return tableTimeService.FindById(id);
    }
    @PutMapping("/create")
    public Table_time Create(@RequestBody TimeRequest tableTime){
        return tableTimeService.Create(tableTime);
    }
    @PostMapping("/update/{id}")
    public Table_time Update(@PathVariable Integer id, @RequestBody TimeRequest tableTime){
        return tableTimeService.Update(id, tableTime);
    }
    @PostMapping("/reset")
    public void ResetTime(){
        tableTimeService.ResetTable();
    }
    @PostMapping("/pay/{id}")
    public int Pay(@PathVariable Integer id){
        return tableTimeService.Pay(id);
    }
    @GetMapping("/findTable/{id}")
    public Iterable<Table_time> FindByTable(@PathVariable Integer id){
        return tableTimeService.FindByTable(id);
    }
}
