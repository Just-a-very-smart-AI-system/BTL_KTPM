package BTL_KTPM.example.Qly_billard.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Time;
import java.time.LocalTime;

@Data
@Entity
@Table(name = "tables_time")
@AllArgsConstructor
@NoArgsConstructor
public class Table_time {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Integer id;

    @ManyToOne
    @JoinColumn(name = "table_id", foreignKey = @ForeignKey(name = "FK_tables_time_tables"), nullable = true)
    Tables tables;
    @ManyToOne
    @JoinColumn(name = "staff_id", foreignKey = @ForeignKey(name = "FK_tables_time_users"), nullable = true)
    Users staff;

    @Column(name = "time_start", nullable = false)
    LocalTime time_start;

    @Column(name = "time_end", nullable = false)
    LocalTime time_end;
}
