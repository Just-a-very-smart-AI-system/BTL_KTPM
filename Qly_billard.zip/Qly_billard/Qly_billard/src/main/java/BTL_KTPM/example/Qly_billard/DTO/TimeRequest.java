package BTL_KTPM.example.Qly_billard.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Time;
import java.time.LocalTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TimeRequest {
    Integer table_id;
    Integer staff_id;
    LocalTime time_start;
    LocalTime time_end;
}
