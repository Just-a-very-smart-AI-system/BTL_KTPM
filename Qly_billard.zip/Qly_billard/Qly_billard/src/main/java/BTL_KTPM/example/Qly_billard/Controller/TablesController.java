package BTL_KTPM.example.Qly_billard.Controller;

import BTL_KTPM.example.Qly_billard.Entity.Enum.Area;
import BTL_KTPM.example.Qly_billard.Entity.Tables;
import BTL_KTPM.example.Qly_billard.Service.TablesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/tables")
public class TablesController {

    @Autowired
    private TablesService tablesService;

    @GetMapping("/findAll")
    public Iterable<Tables> getAllTables() {
        return tablesService.findAll();
    }

    @GetMapping("/findId/{id}")
    public ResponseEntity<Tables> getTableById(@PathVariable Integer id) {
        Tables table = tablesService.findById(id);
        return ResponseEntity.ok(table);
    }

    @PostMapping("/create")
    public Tables createTable(@RequestBody Tables table) {
        return tablesService.save(table);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Tables> updateTable(@PathVariable Integer id, @RequestBody Tables tableDetails) {
        Tables updatedTable = tablesService.update(id, tableDetails);
        return ResponseEntity.ok(updatedTable);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteTable(@PathVariable Integer id) {
        tablesService.delete(id);
        return ResponseEntity.noContent().build();
    }
    @GetMapping("/findArea/{area}")
    public Iterable<Tables> FindByArea(@PathVariable Area area){
        return tablesService.FindByArae(area);
    }
}
