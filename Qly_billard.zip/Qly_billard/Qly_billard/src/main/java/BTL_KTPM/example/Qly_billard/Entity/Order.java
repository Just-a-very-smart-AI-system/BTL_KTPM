package BTL_KTPM.example.Qly_billard.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Time;
import java.util.Date;

@Data
@Entity
@Table(name = "orders")
@AllArgsConstructor
@NoArgsConstructor
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "player_id", foreignKey = @ForeignKey(name = "FK_orders_players"), nullable = true)
    private Player player;

    @ManyToOne
    @JoinColumn(name = "table_id", foreignKey = @ForeignKey(name = "FK_orders_tables"), nullable = true)
    private Tables table;

    @Column(name = "order_date", nullable = true)
    @Temporal(TemporalType.DATE)
    private Date orderDate;

    @Column(name = "start_time", nullable = true)
    private Time startTime;

    @Column(name = "end_time", nullable = true)
    private Time endTime;

    @Column(name = "total_price", nullable = true)
    private Integer totalPrice;
}
