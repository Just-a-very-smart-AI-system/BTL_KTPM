package BTL_KTPM.example.Qly_billard.Entity.Enum;

public enum Position {
    Quan_ly, Nhan_vien;
}
