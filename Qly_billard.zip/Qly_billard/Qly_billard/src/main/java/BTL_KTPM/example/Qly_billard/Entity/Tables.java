package BTL_KTPM.example.Qly_billard.Entity;

import BTL_KTPM.example.Qly_billard.Entity.Enum.Area;
import BTL_KTPM.example.Qly_billard.Entity.Enum.Table_status;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "tables")
@AllArgsConstructor
@NoArgsConstructor
public class Tables{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "table_number", nullable = true)
    private Integer tableNumber;

    @Enumerated(EnumType.STRING)
    @Column(name = "statust", nullable = true)
    private Table_status status;

    @Column(name = "price", nullable = true)
    private Integer price;

    @Column(name = "area", nullable = true)
    private Area area;
}
