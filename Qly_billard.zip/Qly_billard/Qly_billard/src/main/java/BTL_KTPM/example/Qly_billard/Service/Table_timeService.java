package BTL_KTPM.example.Qly_billard.Service;

import BTL_KTPM.example.Qly_billard.DTO.TimeRequest;
import BTL_KTPM.example.Qly_billard.Entity.Enum.Table_status;
import BTL_KTPM.example.Qly_billard.Entity.Table_time;
import BTL_KTPM.example.Qly_billard.Entity.Tables;
import BTL_KTPM.example.Qly_billard.Repository.Table_timeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Time;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.Map;

@Service
public class Table_timeService {
    @Autowired
    private Table_timeRepository tableTimeRepository;
    @Autowired
    private UsersService usersService;
    @Autowired
    private TablesService tablesService;
    public Iterable<Table_time> FindAll(){
        return tableTimeRepository.findAll();
    }

    public Table_time FindById(Integer id){
        return tableTimeRepository.findById(id).orElseThrow(()->new RuntimeException("Khong co id"));
    }

    public Table_time Update(Integer id, TimeRequest newTime){
        Table_time tableTime = FindById(id);

        tableTime.setTime_start(newTime.getTime_start());
        tableTime.setTime_end(newTime.getTime_end());
        tableTime.setStaff(usersService.findById(newTime.getStaff_id()));
        tableTime.setTables(tablesService.findById(newTime.getTable_id()));

        return tableTimeRepository.save(tableTime);
    }
    public Table_time Create(TimeRequest newTime) {
        Table_time tableTime = new Table_time();

        // Lấy tất cả các khoảng thời gian của bàn
        Iterable<Table_time> times = FindByTable(newTime.getTable_id());

        // Kiểm tra xem thời gian của newTime có bị trùng không
        for (Table_time time : times) {
            // Kiểm tra nếu khoảng thời gian mới (newTime) bị trùng
            if ((newTime.getTime_start().isAfter(time.getTime_start()) && newTime.getTime_start().isBefore(time.getTime_end())) ||
                    (newTime.getTime_end().isAfter(time.getTime_start()) && newTime.getTime_end().isBefore(time.getTime_end())) ||
                    (newTime.getTime_start().equals(time.getTime_start()) || newTime.getTime_end().equals(time.getTime_end())) ||
                    (newTime.getTime_start().isBefore(time.getTime_start()) && newTime.getTime_end().isAfter(time.getTime_end()))) {
                throw new IllegalArgumentException("Thời gian bị trùng với khoảng thời gian đã có.");
            }
        }

        // Nếu không bị trùng, tiến hành tạo mới
        tableTime.setTime_start(newTime.getTime_start());
        tableTime.setTime_end(newTime.getTime_end());
        tableTime.setStaff(usersService.findById(1));
        tableTime.setTables(tablesService.findById(newTime.getTable_id()));

        // Reset trạng thái bàn
        ResetTable();

        return tableTimeRepository.save(tableTime);
    }


    public void ResetTable(){
        LocalTime currentTime = LocalTime.now();
        Iterable<Table_time> times = FindAll();
        Map<Integer, Boolean> tableUpdatedMap = new HashMap<>(); // Dùng map để theo dõi bàn đã được cập nhật

        for (Table_time time : times) {
            LocalTime timeStart = time.getTime_start();
            LocalTime timeEnd = time.getTime_end();
            Tables table = time.getTables();

            // Kiểm tra xem bàn này đã được cập nhật trạng thái use hay chưa
            boolean isUpdatedToUse = tableUpdatedMap.getOrDefault(table.getId(), false);

            // Nếu thời gian hiện tại nằm trong khoảng thời gian sử dụng và bàn chưa được cập nhật
            if (!isUpdatedToUse && currentTime.isAfter(timeStart) && currentTime.isBefore(timeEnd)) {
                table.setStatus(Table_status.use);
                tableUpdatedMap.put(table.getId(), true); // Đánh dấu bàn đã được cập nhật thành use
            } else if (!isUpdatedToUse && currentTime.isAfter(timeEnd)) {
                // Nếu đã vượt quá thời gian kết thúc và bàn chưa được cập nhật thành use
                if (!table.getStatus().equals(Table_status.use)) {
                    table.setStatus(Table_status.booked);
                }
            } else if (table.getStatus().equals(Table_status.broken)) {
                // Giữ nguyên trạng thái broken nếu bàn bị hỏng
                table.setStatus(Table_status.broken);
            } else if (!isUpdatedToUse) {
                // Nếu thời gian hiện tại chưa đến thời gian bắt đầu và bàn chưa được cập nhật
                table.setStatus(Table_status.empty);
            }

            // Cập nhật trạng thái bàn
            tablesService.save(table);
        }
    }
    public Iterable<Table_time> FindByTable(Integer id){
        return tableTimeRepository.findAllByTables(id);
    }
    public int Pay(Integer id) {
        LocalTime localTime = LocalTime.now();
        Iterable<Table_time> times = FindByTable(id);

        // Duyệt qua các Table_time để tìm thời gian đang được sử dụng (use)
        Table_time activeTime = null;
        for (Table_time time : times) {
            if (time.getTables().getStatus() == Table_status.use &&
                    localTime.isAfter(time.getTime_start()) &&
                    (time.getTime_end() == null || localTime.isBefore(time.getTime_end()))) {
                activeTime = time;
                break; // Thoát vòng lặp khi tìm thấy Table_time đang sử dụng
            }
        }

        // Nếu không tìm thấy thời gian sử dụng, trả về giá trị 0 hoặc thông báo lỗi
        if (activeTime == null) {
            return 0; // Có thể thay thế bằng ngoại lệ hoặc xử lý lỗi tùy thuộc vào yêu cầu của bạn
        }

        // Tính số giờ và phút sử dụng từ thời gian bắt đầu đến hiện tại
        int hoursUsed = localTime.getHour() - activeTime.getTime_start().getHour();
        int minutesUsed = localTime.getMinute() - activeTime.getTime_start().getMinute();

        // Nếu số phút sử dụng âm, giảm số giờ đi 1 và cộng thêm 60 phút
        if (minutesUsed < 0) {
            minutesUsed += 60;
            hoursUsed -= 1;
        }

        // Tính tổng giá tiền
        Tables table = activeTime.getTables();
        int pricePerHour = table.getPrice();
        int totalPrice = hoursUsed * pricePerHour; // Giá theo giờ

        // Nếu có phút lẻ, tính thêm phí cho phần lẻ của giờ (dựa trên số phút)
        if (minutesUsed > 0) {
            totalPrice += (pricePerHour * minutesUsed) / 60;
        }

        // Cập nhật trạng thái bàn và thời gian kết thúc
        table.setStatus(Table_status.empty); // Đặt lại trạng thái bàn thành trống
        activeTime.setTime_end(localTime); // Cập nhật thời gian kết thúc sử dụng bàn

        // Lưu lại các thay đổi vào database
        tablesService.save(table); // Lưu trạng thái bàn
        tableTimeRepository.save(activeTime); // Lưu thời gian bàn

        // Trả về tổng số tiền
        return totalPrice;
    }

}
