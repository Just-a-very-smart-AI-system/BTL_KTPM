package BTL_KTPM.example.Qly_billard.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

@Data
@Entity
@Table(name = "bills")
@AllArgsConstructor
@NoArgsConstructor
public class Bills {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "user_id", foreignKey = @ForeignKey(name = "FK__users"), nullable = true)
    private Users user;

    @Column(name = "total_money", nullable = true)
    private Integer totalMoney;

    @Column(name = "date_pay", nullable = true)
    @Temporal(TemporalType.DATE)
    private LocalDate datePay;

    @Column(name = "time", nullable = true)
    private LocalTime time;
}

