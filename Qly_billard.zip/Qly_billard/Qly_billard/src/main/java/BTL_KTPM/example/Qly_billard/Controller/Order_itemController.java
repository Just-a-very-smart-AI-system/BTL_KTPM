package BTL_KTPM.example.Qly_billard.Controller;

import BTL_KTPM.example.Qly_billard.DTO.Order_itemRequest;
import BTL_KTPM.example.Qly_billard.Entity.Order_item;
import BTL_KTPM.example.Qly_billard.Service.Order_itemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/order_items")
public class Order_itemController {

    @Autowired
    private Order_itemService orderItemService;

    @GetMapping("/findAll")
    public Iterable<Order_item> getAllOrderItems() {
        return orderItemService.findAll();
    }

    @GetMapping("findId/{id}")
    public ResponseEntity<Order_item> getOrderItemById(@PathVariable Integer id) {
        Order_item orderItem = orderItemService.findById(id);
        return ResponseEntity.ok(orderItem);
    }

    @PostMapping("/create")
    public Order_item createOrderItem(@RequestBody Order_itemRequest orderItem) {
        return orderItemService.save(orderItem);
    }

    @PutMapping("update/{id}")
    public ResponseEntity<Order_item> updateOrderItem(@PathVariable Integer id, @RequestBody Order_item orderItemDetails) {
        Order_item updatedOrderItem = orderItemService.update(id, orderItemDetails);
        return ResponseEntity.ok(updatedOrderItem);
    }

    @DeleteMapping("delete/{id}")
    public ResponseEntity<Void> deleteOrderItem(@PathVariable Integer id) {
        orderItemService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
