package BTL_KTPM.example.Qly_billard.Entity.Enum;
public enum Table_status {
    empty, booked, use,broken
}
