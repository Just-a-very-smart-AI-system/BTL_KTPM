package BTL_KTPM.example.Qly_billard.Service;

import BTL_KTPM.example.Qly_billard.Entity.Enum.Area;
import BTL_KTPM.example.Qly_billard.Entity.Tables;
import BTL_KTPM.example.Qly_billard.Repository.TablesRepository; // Đảm bảo bạn đã tạo TablesRepository
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TablesService {

    @Autowired
    private TablesRepository tablesRepository;

    // Tìm tất cả các table
    public Iterable<Tables> findAll() {
        return tablesRepository.findAll();
    }

    // Tìm table theo ID
    public Tables findById(Integer id) {
        return tablesRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Table not found for this id: " + id));
    }

    // Lưu table mới
    public Tables save(Tables table) {
        return tablesRepository.save(table);
    }

    // Cập nhật table theo ID
    public Tables update(Integer id, Tables tableDetails) {
        Tables table = findById(id);
        table.setTableNumber(tableDetails.getTableNumber());
        table.setStatus(tableDetails.getStatus());
        table.setPrice(tableDetails.getPrice());
        return tablesRepository.save(table);
    }

    // Xóa table theo ID
    public void delete(Integer id) {
        Tables table = findById(id);
        tablesRepository.delete(table);
    }
    public Iterable<Tables> FindByArae(Area area){
        return tablesRepository.findByArea(area);
    }
}
