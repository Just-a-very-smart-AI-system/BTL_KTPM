package BTL_KTPM.example.Qly_billard.Service;

import BTL_KTPM.example.Qly_billard.DTO.Order_itemRequest;
import BTL_KTPM.example.Qly_billard.Entity.Items;
import BTL_KTPM.example.Qly_billard.Entity.Order_item;
import BTL_KTPM.example.Qly_billard.Repository.Order_itemRepository; // Đảm bảo bạn đã tạo Order_itemRepository
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Order_itemService {

    @Autowired
    private Order_itemRepository orderItemRepository;
    @Autowired
    private ItemsService itemsService;
    @Autowired
    private TablesService tablesService;
    // Tìm tất cả các order item
    public Iterable<Order_item> findAll() {
        return orderItemRepository.findAll();
    }

    // Tìm order item theo ID
    public Order_item findById(Integer id) {
        return orderItemRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order item not found for this id: " + id));
    }

    // Lưu order item mới
    public Order_item save(Order_itemRequest orderItem) {
        Order_item newOreder = new Order_item();
        Items items = itemsService.findById(orderItem.getItem());
        newOreder.setItem(items);
        newOreder.setTable(tablesService.findById(orderItem.getTable_id()));
        newOreder.setQuantity(orderItem.getQuantity());
        newOreder.setTotalPrice(items.getPrice() * orderItem.getQuantity());

        return orderItemRepository.save(newOreder);
    }

    // Cập nhật order item theo ID
    public Order_item update(Integer id, Order_item orderItemDetails) {
        Order_item orderItem = findById(id);
        orderItem.setTable(orderItemDetails.getTable());
        orderItem.setItem(orderItemDetails.getItem());
        orderItem.setQuantity(orderItemDetails.getQuantity());
        orderItem.setTotalPrice(orderItemDetails.getTotalPrice());
        return orderItemRepository.save(orderItem);
    }

    // Xóa order item theo ID
    public void delete(Integer id) {
        Order_item orderItem = findById(id);
        orderItemRepository.delete(orderItem);
    }
}
