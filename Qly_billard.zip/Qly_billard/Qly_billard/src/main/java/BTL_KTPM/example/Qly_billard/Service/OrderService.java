package BTL_KTPM.example.Qly_billard.Service;

import BTL_KTPM.example.Qly_billard.Entity.Order;
import BTL_KTPM.example.Qly_billard.Repository.OrderRepository; // Đảm bảo bạn đã tạo OrderRepository
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    // Tìm tất cả các đơn hàng
    public Iterable<Order> findAll() {
        return orderRepository.findAll();
    }

    // Tìm đơn hàng theo ID
    public Order findById(Integer id) {
        return orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found for this id: " + id));
    }

    // Lưu đơn hàng mới
    public Order save(Order order) {
        return orderRepository.save(order);
    }

    // Cập nhật đơn hàng theo ID
    public Order update(Integer id, Order orderDetails) {
        Order order = findById(id);
        order.setPlayer(orderDetails.getPlayer());
        order.setTable(orderDetails.getTable());
        order.setOrderDate(orderDetails.getOrderDate());
        order.setStartTime(orderDetails.getStartTime());
        order.setEndTime(orderDetails.getEndTime());
        order.setTotalPrice(orderDetails.getTotalPrice());
        return orderRepository.save(order);
    }

    // Xóa đơn hàng theo ID
    public void delete(Integer id) {
        Order order = findById(id);
        orderRepository.delete(order);
    }
}
