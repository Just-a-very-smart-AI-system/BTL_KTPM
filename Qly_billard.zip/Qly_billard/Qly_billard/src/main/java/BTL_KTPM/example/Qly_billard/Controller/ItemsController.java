package BTL_KTPM.example.Qly_billard.Controller;

import BTL_KTPM.example.Qly_billard.Entity.Items;
import BTL_KTPM.example.Qly_billard.Service.ItemsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/items")
public class ItemsController {

    @Autowired
    private ItemsService itemsService;

    @GetMapping("/findAll")
    public Iterable<Items> getAllItems() {
        return itemsService.findAll();
    }

    @GetMapping("findId/{id}")
    public ResponseEntity<Items> getItemById(@PathVariable Integer id) {
        Items item = itemsService.findById(id);
        return ResponseEntity.ok(item);
    }

    @PostMapping("/create")
    public Items createItem(@RequestBody Items item) {
        return itemsService.save(item);
    }

    @PutMapping("update/{id}")
    public ResponseEntity<Items> updateItem(@PathVariable Integer id, @RequestBody Items itemDetails) {
        Items updatedItem = itemsService.update(id, itemDetails);
        return ResponseEntity.ok(updatedItem);
    }

    @DeleteMapping("delete/{id}")
    public ResponseEntity<Void> deleteItem(@PathVariable Integer id) {
        itemsService.delete(id);
        return ResponseEntity.noContent().build();
    }
    @GetMapping("/findFood")
    public Iterable<Items> FindFood(){
        return itemsService.findFood();
    }
    @GetMapping("/findDrink")
    public Iterable<Items> FindDrink(){
        return itemsService.findDrink();
    }
}
