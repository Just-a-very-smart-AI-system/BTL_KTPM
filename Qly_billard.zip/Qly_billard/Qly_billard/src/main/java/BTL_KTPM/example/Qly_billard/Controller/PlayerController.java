package BTL_KTPM.example.Qly_billard.Controller;

import BTL_KTPM.example.Qly_billard.Entity.Player;
import BTL_KTPM.example.Qly_billard.Service.PlayerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/players")
public class PlayerController {

    @Autowired
    private PlayerService playerService;

    @GetMapping("/findAll")
    public Iterable<Player> getAllPlayers() {
        return playerService.findAll();
    }

    @GetMapping("findId/{id}")
    public ResponseEntity<Player> getPlayerById(@PathVariable Integer id) {
        Player player = playerService.findById(id);
        return ResponseEntity.ok(player);
    }

    @PostMapping("/create")
    public Player createPlayer(@RequestBody Player player) {
        return playerService.save(player);
    }

    @PutMapping("update/{id}")
    public ResponseEntity<Player> updatePlayer(@PathVariable Integer id, @RequestBody Player playerDetails) {
        Player updatedPlayer = playerService.update(id, playerDetails);
        return ResponseEntity.ok(updatedPlayer);
    }

    @DeleteMapping("delete/{id}")
    public ResponseEntity<Void> deletePlayer(@PathVariable Integer id) {
        playerService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
