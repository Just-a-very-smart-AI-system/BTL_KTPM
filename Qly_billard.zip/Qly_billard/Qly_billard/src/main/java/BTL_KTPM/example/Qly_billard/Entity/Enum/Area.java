package BTL_KTPM.example.Qly_billard.Entity.Enum;

public enum Area {
    normal, smoke, vip
}
