package BTL_KTPM.example.Qly_billard.Service;

import BTL_KTPM.example.Qly_billard.Entity.Users;
import BTL_KTPM.example.Qly_billard.Repository.UsersRepository; // Đảm bảo bạn đã tạo UsersRepository
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UsersService {

    @Autowired
    private UsersRepository usersRepository;

    // Tìm tất cả các user
    public Iterable<Users> findAll() {
        return usersRepository.findAll();
    }

    // Tìm user theo ID
    public Users findById(Integer id) {
        return usersRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found for this id: " + id));
    }

    // Lưu user mới
    public Users save(Users user) {
        return usersRepository.save(user);
    }

    // Cập nhật user theo ID
    public Users update(Integer id, Users userDetails) {
        Users user = findById(id);
        user.setUserName(userDetails.getUserName());
        user.setPosition(userDetails.getPosition());
        return usersRepository.save(user);
    }

    // Xóa user theo ID
    public void delete(Integer id) {
        Users user = findById(id);
        usersRepository.delete(user);
    }
}
