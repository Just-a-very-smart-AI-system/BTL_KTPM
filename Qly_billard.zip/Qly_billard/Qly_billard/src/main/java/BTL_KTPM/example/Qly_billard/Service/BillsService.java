package BTL_KTPM.example.Qly_billard.Service;

import BTL_KTPM.example.Qly_billard.DTO.BillRequest;
import BTL_KTPM.example.Qly_billard.Entity.Bills;
import BTL_KTPM.example.Qly_billard.Repository.BillsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.reflect.Array;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Service
public class BillsService {

    @Autowired
    private BillsRepository billsRepository;
    @Autowired
    private UsersService usersService;

    public Iterable<Bills> findAll() {
        return billsRepository.findAll();
    }

    public Bills findById(Integer id) {
        return billsRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Bill not found for this id: " + id));
    }

    public Bills save(BillRequest bill) {
        Bills newBill = new Bills();

        newBill.setUser(usersService.findById(bill.getUser()));
        newBill.setTime(bill.getTime());
        newBill.setTotalMoney(bill.getTotalMoney());
        newBill.setDatePay(bill.getDatePay());

        return billsRepository.save(newBill);
    }

    public Bills update(Integer id, Bills billsDetails) {
        Bills bills = findById(id);
        bills.setTotalMoney(billsDetails.getTotalMoney());
        bills.setDatePay(billsDetails.getDatePay());
        bills.setUser(billsDetails.getUser());
        return billsRepository.save(bills);
    }

    public void delete(Integer id) {
        Bills bills = findById(id);
        billsRepository.delete(bills);
    }
    public Integer allBillToday(){
        Iterable<Bills> bills = findByDate(LocalDate.now());

        int money = 0;
        for(Bills bill : bills){
            money += bill.getTotalMoney();
        }

        return money;
    }
    public Integer allBillYesterday() {
        LocalDate yesterday = LocalDate.now().minusDays(1);

        Iterable<Bills> bills = findByDate(yesterday);

        int money = 0;
        for (Bills bill : bills) {
            money += bill.getTotalMoney();
        }

        return money;
    }
    public int[] calculateHourlyRevenue() {
        int[] hourlyRevenue = new int[8];
        LocalTime now = LocalTime.now();
        LocalDate today = LocalDate.now();

        for (int i = 0; i < 8; i++) {
            LocalTime startTime = now.minusHours(i + 1);
            LocalTime endTime = now.minusHours(i);

            Iterable<Bills> billsInHour = billsRepository.findByDatePayAndTimeBetween(today, startTime, endTime);

            int totalMoneyInHour = 0;
            for (Bills bill : billsInHour) {
                totalMoneyInHour += bill.getTotalMoney();
            }

            hourlyRevenue[7 - i] = totalMoneyInHour;
        }

        return hourlyRevenue;
    }


    public Iterable<Bills> findByDate(LocalDate date){
        return billsRepository.findByDatePay(date);
    }
}

