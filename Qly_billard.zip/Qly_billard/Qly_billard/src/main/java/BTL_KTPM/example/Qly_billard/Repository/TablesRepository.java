package BTL_KTPM.example.Qly_billard.Repository;

import BTL_KTPM.example.Qly_billard.Entity.Enum.Area;
import BTL_KTPM.example.Qly_billard.Entity.Items;
import BTL_KTPM.example.Qly_billard.Entity.Tables;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TablesRepository extends JpaRepository<Tables,Integer> {
    Iterable<Tables> findByArea(Area area);
}
