package BTL_KTPM.example.Qly_billard.DTO;

import BTL_KTPM.example.Qly_billard.Entity.Items;
import BTL_KTPM.example.Qly_billard.Entity.Order;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Order_itemRequest {
    private Integer table_id;

    private Integer item;

    private Integer quantity;

}
