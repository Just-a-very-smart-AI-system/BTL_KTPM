package BTL_KTPM.example.Qly_billard.Service;

import BTL_KTPM.example.Qly_billard.Entity.Player;

import BTL_KTPM.example.Qly_billard.Repository.PlayerRerpository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PlayerService {

    @Autowired
    private PlayerRerpository playerRepository;

    // Tìm tất cả các player
    public Iterable<Player> findAll() {
        return playerRepository.findAll();
    }

    // Tìm player theo ID
    public Player findById(Integer id) {
        return playerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Player not found for this id: " + id));
    }

    // Lưu player mới
    public Player save(Player player) {
        return playerRepository.save(player);
    }

    // Cập nhật player theo ID
    public Player update(Integer id, Player playerDetails) {
        Player player = findById(id);
        player.setName(playerDetails.getName());
        player.setStd(playerDetails.getStd());
        return playerRepository.save(player);
    }

    // Xóa player theo ID
    public void delete(Integer id) {
        Player player = findById(id);
        playerRepository.delete(player);
    }
}
