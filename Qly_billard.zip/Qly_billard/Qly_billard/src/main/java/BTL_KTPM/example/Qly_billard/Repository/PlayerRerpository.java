package BTL_KTPM.example.Qly_billard.Repository;


import BTL_KTPM.example.Qly_billard.Entity.Player;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlayerRerpository extends JpaRepository<Player,Integer> {
}
