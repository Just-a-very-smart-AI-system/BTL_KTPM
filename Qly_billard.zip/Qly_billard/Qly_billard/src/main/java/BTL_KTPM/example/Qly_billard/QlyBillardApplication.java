package BTL_KTPM.example.Qly_billard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QlyBillardApplication {

	public static void main(String[] args) {
		SpringApplication.run(QlyBillardApplication.class, args);
	}

}
