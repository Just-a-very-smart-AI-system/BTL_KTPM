// Định nghĩa một hàm để gọi tất cả các API
function loadData() {
    // Gọi API lấy số đơn theo ngày hôm nay
    fetch('http://localhost:8080/bills/findDate/' + new Date().toISOString().split('T')[0])
        .then(response => response.json())
        .then(data => {
            const orderCount = data.length; // Giả sử data là một mảng chứa các hóa đơn
            document.getElementById('orderCount').innerText = orderCount + " đơn đã xong";
        })
        .catch(error => console.error('Error fetching order count:', error));

    // Gọi API lấy tổng tiền hôm nay
    fetch('http://localhost:8080/bills/moneyToday')
        .then(response => response.json())
        .then(data => {
            const moneyToday = data.toLocaleString(); // Chuyển đổi thành chuỗi có dấu phẩy
            document.getElementById('moneyToday').innerText = moneyToday + " VND";
        })
        .catch(error => console.error('Error fetching money today:', error));

    // Gọi API lấy tổng tiền hôm qua
    fetch('http://localhost:8080/bills/moneyYesterday')
        .then(response => response.json())
        .then(data => {
            const moneyYesterday = data.toLocaleString(); // Chuyển đổi thành chuỗi có dấu phẩy
            document.getElementById('moneyYesterday').innerText = moneyYesterday + " VND";
        })
        .catch(error => console.error('Error fetching money yesterday:', error));
}

// Gọi hàm loadData khi trang web được tải
document.addEventListener('DOMContentLoaded', loadData);

document.addEventListener('DOMContentLoaded', function() {
    fetch('http://localhost:8080/bills/moneyToday')
        .then(response => response.json())
        .then(data => {
            document.getElementById('total-money-today').textContent = data.toLocaleString('vi-VN') + ' VND';
        })
        .catch(error => console.error('Error fetching moneyToday:', error));

    fetch('http://localhost:8080/bills/moneyByHour')
        .then(response => response.json())
        .then(data => {
            const hourlyChart = document.getElementById('hourly-chart');
            const maxRevenue = Math.max(...data);

            // Kiểm tra nếu maxRevenue là 0
            if (maxRevenue === 0) {
                console.warn("Max revenue is 0, no chart will be displayed");
                return;
            }

            hourlyChart.innerHTML = '';

            const currentTime = new Date();

            for (let i = 0; i < data.length; i++) {
                const bar = document.createElement('div');
                bar.classList.add('bar');

                const barHeight = (data[i] / maxRevenue) * 100;

                // Đảm bảo chiều cao không âm
                const validBarHeight = barHeight >= 0 ? barHeight : 0;

                console.log(`Doanh thu: ${data[i]}, Chiều cao: ${validBarHeight}%`);

                bar.innerHTML = `
                    <div class="height" style="height: ${validBarHeight}%;"></div>
                    <span>${getFormattedTime(currentTime, i)}h</span>
                `;

                hourlyChart.appendChild(bar);
            }
        })
        .catch(error => console.error('Error fetching moneyByHour:', error));

    function getFormattedTime(currentTime, hoursAgo) {
        const date = new Date(currentTime);
        date.setHours(currentTime.getHours() - (7 - hoursAgo));
        return date.getHours();
    }
});
const hourlyData = [120, 80, 50, 200, 130, 180, 90, 100]; // Dữ liệu giả
const hourlyChart = document.getElementById('hourly-chart');

hourlyData.forEach((value, index) => {
    const bar = document.createElement('div');
    bar.classList.add('bar');
    const heightDiv = document.createElement('div');
    heightDiv.classList.add('height');
    heightDiv.style.height = `${value}px`; // Thiết lập chiều cao cho thanh
    const label = document.createElement('span');
    label.innerText = `${index + 1}h`;

    bar.appendChild(heightDiv);
    bar.appendChild(label);
    hourlyChart.appendChild(bar);
});
const yAxis = document.querySelector('.y-axis');
const maxGridValue = Math.max(...hourlyData);

for (let i = 0; i <= 5; i++) {
    const gridLine = document.createElement('div');
    gridLine.classList.add('grid-line');
    const label = document.createElement('span');
    label.innerText = `${(maxGridValue / 5) * i}`; // Nhãn cho trục y
    gridLine.appendChild(label);
    yAxis.appendChild(gridLine);
}

